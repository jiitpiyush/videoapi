<?php
  ob_clean();
  ob_start();
  require_once("facebook-sdk-v5/autoload.php");
  require_once("mysrc/config.php");
  include "mysrc/functions.php";
  include "mysrc/user_function.php";

  session_start();

  if(valid_token()){

      $name = $_POST['name'];

       $fb = new Facebook\Facebook([
       'app_id' => $config['App_ID'],
       'app_secret' => $config['App_Secret'],
       'default_graph_version' => 'v2.6',
       ]);

     $data = [
       'title' => "anything",
       'description' => "anything",
       'source' => $fb->videoToUpload("../../uploads/".$name),
     ];
     $f_id = get_fb_id();
     $token = get_token();
      try{
          $response = $fb->post("/$f_id/videos", $data, $token);
      } 
      catch(Facebook\Exceptions\FacebookResponseException $e) {
         // When Graph returns an error
         echo 'Graph returned an error: ' . $e->getMessage();
         exit;
      } 
      catch(Facebook\Exceptions\FacebookSDKException $e) {
         // When validation fails or other local issues
         echo 'Facebook SDK returned an error: ' . $e->getMessage();
         exit;
      }

     $graphNode = $response->getGraphNode();

     echo $graphNode['id'];
  }
  else{
    $id = $config['App_ID'];
    $cb = $config['callback_url'];
    $fb_uri = "https://www.facebook.com/dialog/oauth?client_id=$id&redirect_uri=$cb&scope=email,publish_actions";
    header("Location: $fb_uri");
  }



?>