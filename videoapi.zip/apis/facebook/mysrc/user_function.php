<?php
	function valid_token(){
		$base = $_SERVER['DOCUMENT_ROOT'];
		include "$base/constants.php";
		date_default_timezone_set('Asia/Kolkata');
		
		//session_start();

		$id = $_SESSION['uid'];
		include "$base/connect/nect.php";
		$query = "SELECT fb_expire,fb_token_time FROM $fb_token_table WHERE uid = ?";
		$stmt = $conn->prepare($query);
		if($stmt->execute(array($id))){
			$row = $stmt->rowCount();
			if($row > 0){
				$conn = null;
				$row = $stmt->fetch(PDO::FETCH_ASSOC);
				$t_time = $row['fb_token_time'];
				$expire_seconds = $row['fb_expire'];
				$time_now = date('Y-m-d H:i:s');
				$calculated_seconds = $time_now - $t_time;
				if($calculated_seconds < $expire_seconds){
					return 1;
				}
			}
		}
		return 0;
	}


	function fetch_fb_id($token){
		$graph_url = "https://graph.facebook.com/me?fields=id&access_token=" . $token;
		$user = json_decode(getHTML($graph_url));
		$id = $user->id;
		return $id;
	}

	function get_fb_id(){
		$base = $_SERVER['DOCUMENT_ROOT'];
		include "$base/constants.php";
		include "$base/connect/nect.php";

		$q = "SELECT fb_id FROM $login_table WHERE uid = ?";
		$stm = $conn->prepare($q);
		if($stm->execute(array($id))){
				$row = $stm->fetch(PDO::FETCH_ASSOC);
				$conn = '';
				return $row['fb_id'];
		}
	}

	function get_fb_token(){
		$base = $_SERVER['DOCUMENT_ROOT'];
		include "$base/constants.php";
		include "$base/connect/nect.php";

		$q = "SELECT fb_token FROM $fb_token_table WHERE uid = ?";
		$stm = $conn->prepare($q);
		if($stm->execute(array($id))){
				$row = $stm->fetch(PDO::FETCH_ASSOC);
				$conn = '';
				return $row['fb_token'];
		}
	}

	function exist_fb_id($fb_id){
		$base = $_SERVER['DOCUMENT_ROOT'];
		include "$base/constants.php";
		include "$base/connect/nect.php";

		$q = "SELECT uid FROM $login_table WHERE fb_id = ?";
		$stm = $conn->prepare($q);
		if($stm->execute(array($fb_id))){
			if($stm->rowCount() > 0){
				$row = $stm->fetch(PDO::FETCH_ASSOC);
				$conn = '';
				return $row['uid'];
			}
			else{
				$conn = '';
				return 0;
			}
		}
		else{
			$conn = '';
			return 1;
		}
	}

	function set_token($token,$livetime,$time){
		session_start();
		$base = $_SERVER['DOCUMENT_ROOT'];
		include "$base/constants.php";
		$id = $_SESSION['uid'];
		require_once("$base/connect/nect.php");
		$fb_id = fetch_fb_id($token);
		$r_id = exist_fb_id($fb_id);
		if(!$r_id ){
					$query = "UPDATE $login_table SET fb_id = :fb WHERE uid = :id";
					$stmt = $conn->prepare($query);
					$stmt->bindParam(':fb',$fb_id);
					$stmt->bindParam(':id',$id);
					if(!($stmt->execute())){
						echo $stmt->getMessage();
						return 0;
					}

					$query = "INSERT INTO $fb_token_table VALUES(?,?,?,?,?)";
					$stmt = $conn->prepare($query);

					if($stmt->execute(array($id,$token,'',$livetime,$time))){
						$conn = null;
						return 1;
					}
					else{
						$conn = null;
						return 0;
					}
		}
		else if($r_id == $id){
					$query = "UPDATE $fb_token_table SET fb_token = ? , fb_expire = ?, fb_token_time = ? WHERE uid = ?";
					$stmt = $conn->prepare($query);

					if($stmt->execute(array($token,$livetime,$time,$id))){
						$conn = null;
						return 1;
					}
					else{
						$conn = null;
						return 0;
					}
		}
		else if($r_id != $id){
			return 2;
		}
		else{
			return 3;
		}
	}
?>