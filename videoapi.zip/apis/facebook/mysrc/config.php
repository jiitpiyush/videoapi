<?php
	$config['callback_url']=   'http://videoapi.edubrandmedia.com/apis/facebook/tockens.php/?fbTrue=true';
	$config['App_ID']      =   '245789092438893';
	$config['App_Secret']  =   'b28feca16cb05626c5a59b791fd1fd42'; 
?>