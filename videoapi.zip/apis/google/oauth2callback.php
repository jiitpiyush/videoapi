<?php
ob_clean();
ob_start();
session_start();
require_once 'google-api-php-client/src/Google/autoload.php';


$client = new Google_Client();
$client->setAuthConfigFile('client_secret.json');
$client->setAccessType("offline");
$client->setRedirectUri('http://' . $_SERVER['HTTP_HOST'] . '/google/oauth2callback.php');
$client->addScope('https://www.googleapis.com/auth/youtube.upload');

if (! isset($_GET['code'])) {
  $auth_url = $client->createAuthUrl();
  //echo "<script type='text/javascript'>alert(".$auth_url.")</script>";
  header('Location: ' . filter_var($auth_url, FILTER_SANITIZE_URL));
} else {
  $client->authenticate($_GET['code']);
  $token = $client->getAccessToken();
  $_SESSION['access_token'] = $token;
  $redirect_uri = 'http://' . $_SERVER['HTTP_HOST'] . '/google';
  header('Location: ' . filter_var($redirect_uri, FILTER_SANITIZE_URL));
}
?>