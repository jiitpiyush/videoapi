<?php
session_start();
	try{
		$base = $_SERVER['DOCUMENT_ROOT'];
		include "$base/connect/nect.php";
		include "$base/constants.php";
		include "$base/login/is_login.php";

		if(islogin()){
			$id = $_SESSION['uid'];
			$name = $_POST['name'];
			$query = "INSERT INTO $video_url_table (url) VALUES(?)";
			$stmt = $conn->prepare($query);
			if($stmt->execute(array($name))){
				$url = "$base/apis/facebook/index.php";
				$query = array($name);
				$options = array('http' => array(
												'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
												'method'  => 'POST',
												'content' => http_build_query($query),
												),
								);
				$context  = stream_context_create($options);
				$fb_video_id = file_get_contents($url, false, $context);

				 $last_id = $conn->lastInsertId();
				 $query = "INSERT INTO $user_videos_table (uid,video_id,fb_video_id) VALUES(?,?,?)";
				 $stm = $conn->prepare($query);
				 if($stm->execute(array($id,$last_id,$fb_video_id))){
				 	echo $fb_video_id;
				 }
				 else{
				 	echo "fail";
				 }
			}
			else{
				echo "fail";
			}
		}
		else{
			echo "login";
		}
	}
	catch(PDOException $e){
	    echo "<br>" . $e->getMessage();
    }
?>