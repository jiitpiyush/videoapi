<?php
	session_start();
	$base = $_SERVER['DOCUMENT_ROOT'];
	include "$base/login/is_login.php";

	if(islogin()){
		include "main.php";
	}
	else{
		// header("Location: /login/");
		include "$base/login/index.php";
	}
?>
