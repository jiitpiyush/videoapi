<form action="upload.php" method="post" enctype="multipart/form-data">
    <label for="file">Select a file:</label><br/>
    <input type="file" name="userfile"> <br/>
    <input type="text" name="title" placeholder="Title of Video"> <br/>
    <input type="text" name="desc" placeholder="Description"> <br/>
    <button>Upload File</button>
</form>