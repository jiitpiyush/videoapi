<?php
 echo phpinfo();
 ?>