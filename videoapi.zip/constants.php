<?php
	
	$fb_token_table = "fb_token_wizard";
	$login_table = "api_login";
?>